﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicación_broma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_2_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// El método `MoverBoton` se llama en el controlador de eventos `btn_2_MouseMove` para mover el botón `btn_2` a una ubicación aleatoria dentro de los límites del formulario.
        /// Si la ubicación del botón coincide con la ubicación de `btn_1` o `lbl_Mensage`, se vuelve a llamar al método `MoverBoton` para mover el botón a una ubicación diferente.
        /// </summary>

        public void MoverBoton()
        {
            Random r = new Random();
            int x = r.Next(0, this.Width - btn_2.Width);
            int y = r.Next(0, this.Height - btn_2.Height);
            btn_2.Location = new Point(x, y);
        }

        /// <summary>
        /// Este código maneja el evento MouseMove del botón btn_2. 
        /// Cuando el mouse se mueve sobre el botón, se llama al método MoverBoton() para mover aleatoriamente el botón a una nueva ubicación en el formulario.
        /// Luego, una declaración if verifica si la ubicación del botón se superpone con la ubicación de btn_1 o lbl_Mensage. 
        /// Si hay una superposición, se vuelve a llamar al método MoverBoton() para mover el botón a una nueva ubicación.
        /// Esto crea una broma en la que el usuario intenta atrapar el botón en movimiento, pero sigue evadiendo el cursor.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        
        private void btn_2_MouseMove(object sender, MouseEventArgs e)
        {
            MoverBoton();

            if (btn_2.Location == btn_1.Location || btn_2.Location == lbl_Mensage.Location )
            {
                MoverBoton();
            }
        }

        /// <summary>
        /// Este código maneja el evento de clic de un botón llamado `btn_1`. 
        /// Cuando se hace clic en el botón, muestra un panel llamado `pnl_1`.
        /// </summary>
        
        private void btn_1_Click(object sender, EventArgs e)
        {
            pnl_1.Show();
        }

        /// <summary>
        /// El método `Form1_Load` es un controlador de eventos integrado que se llama cuando se carga el formulario.
        /// En este método, el control `pnl_1` está oculto y la propiedad `TabStop` de los controles `btn_1` y `btn_2` se establece en `false`. 
        /// Esto evita que los controles reciban el foco cuando el usuario presiona la tecla Tabulador.
        /// </summary>
    
        private void Form1_Load(object sender, EventArgs e)
        {
            pnl_1.Hide(); 
            btn_2.TabStop = false;
            btn_1.TabStop = false;
        }
    }
}
