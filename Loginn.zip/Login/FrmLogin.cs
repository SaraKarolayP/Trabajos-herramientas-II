﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class FrmLogin : Form
    {
        /// <summary>
        /// `int contador = 0;` inicializa una variable llamada `contador` con un valor de 0. 
        /// </summary>

        int contador = 0;
        public FrmLogin()
        {
            InitializeComponent();
        }

        /// <summary>
        /// La función borra el texto de las casillas de texto "Usuario" y "Clave" cuando se pulsa "Cancelar".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            txt_Usuario.Clear();
            txt_Clave.Clear();

        }

        /// <summary>
        /// Este es el controlador de eventos para el clic del botón "Ingresar" en un formulario de inicio de sesión.
        /// Comprueba si el nombre de usuario y la contraseña ingresados ​​coinciden con los valores esperados.
        /// Si coinciden, oculta el formulario de inicio de sesión y muestra el formulario principal(FrmInicio).
        /// Si no coinciden, muestra un mensaje de error y borra los cuadros de texto para el nombre de usuario y contraseña.
        /// También incrementa un contador para los intentos de inicio de sesión fallidos, y si el contador alcanza 3, muestra un mensaje de que el usuario está bloqueado y elimina el formulario de inicio de sesión.
        /// </summary>
       
        private void btn_Ingresar_Click(object sender, EventArgs e)
        {
            if (txt_Usuario.Text == "Sara Parra" && txt_Clave.Text == "administradora")
            {
                FrmInicio frmInicio = new FrmInicio();
                this.Hide();
                frmInicio.Show();
            }
            else
            {
                MessageBox.Show("El usuario o la clave son incorrectos");
                contador++;
                txt_Usuario.Clear();
                txt_Clave.Clear();

                if (contador == 3)
                {
                    MessageBox.Show("Usuario bloqueado");
                    this.Dispose();
                }
            }
        }
    }
}
