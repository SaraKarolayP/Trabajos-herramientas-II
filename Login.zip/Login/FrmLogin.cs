﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class FrmLogin : Form
    {
        int contador = 0;
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            txt_Usuario.Clear();
            txt_Clave.Clear();

        }

        private void btn_Ingresar_Click(object sender, EventArgs e)
        {
            if (txt_Usuario.Text == "Sara Parra" && txt_Clave.Text == "administradora")
            {
                FrmInicio frmInicio = new FrmInicio();
                this.Hide();
                frmInicio.Show();
            }
            else
            {
                MessageBox.Show("El usuario o la clave son incorrectos");
                contador++;
                txt_Usuario.Clear();
                txt_Clave.Clear();

                if (contador == 3)
                {
                    MessageBox.Show("Usuario bloqueado");
                    this.Dispose();
                }
            }
        }
    }
}
